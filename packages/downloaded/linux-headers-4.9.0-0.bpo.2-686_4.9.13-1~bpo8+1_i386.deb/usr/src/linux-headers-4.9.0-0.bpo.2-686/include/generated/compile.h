/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Debian 4.9.13-1~bpo8+1 (2017-02-27)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 4.9.2 (Debian 4.9.2-10) "
